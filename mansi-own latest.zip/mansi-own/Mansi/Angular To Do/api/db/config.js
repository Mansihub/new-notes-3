const config = {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'todo',
  };
export default config;