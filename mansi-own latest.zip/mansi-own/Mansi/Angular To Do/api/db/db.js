import mysql from 'mysql2/promise'
import config from './config.js'

const pool = mysql.createPool(config);

const connectDB = async () => {
  pool.getConnection((err, connection) => {
    if (err) {
      console.log({ error: err.message });
    }
    else{
      console.log('connection to database established')
      }
      connection.release();
    });

};

export {connectDB,pool};
