import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from 'cookie-parser';
import {connectDB} from "./db/db.js";
import authRoutes from "./routes/auth.js";
import taskRoutes from "./routes/tasks.js";

dotenv.config();
const port = process.env.PORT;

const app = express();
app.use(cors({ origin: 'http://localhost:4200' ,credentials:true}));
app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use("/", authRoutes);
app.use("/", taskRoutes);

connectDB();

app.listen(port, () => {
  console.log(`Server running on port:`, port);
});